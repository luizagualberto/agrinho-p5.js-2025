let basket; // Cesta

let fruits = []; // Array de frutas

let score = 0; // Pontuação

function setup() {

  createCanvas(400, 600); // Tamanho da tela

  basket = new Basket(); // Cria a cesta

}

function draw() {

  background(135, 206, 235); // Cor do céu

  // Desenha a cesta

  basket.show();

  basket.move();

  // Adiciona novas frutas

  if (frameCount % 60 === 0) {

    fruits.push(new Fruit());

  }

  // Atualiza e desenha as frutas

  for (let i = fruits.length - 1; i >= 0; i--) {

    fruits[i].fall();

    fruits[i].show();

    // Verifica se a fruta foi pega pela cesta

    if (fruits[i].hits(basket)) {

      score++;

      fruits.splice(i, 1); // Remove a fruta que foi pega

    } else if (fruits[i].offScreen()) {

      fruits.splice(i, 1); // Remove a fruta que saiu da tela

    }

  }

  // Mostra a pontuação

  fill(0);

  textSize(24);

  text("Pontuação: " + score, 10, 30);

}

function keyPressed() {

  if (keyCode === LEFT_ARROW) {

    basket.move(-1); // Move para a esquerda

  } else if (keyCode === RIGHT_ARROW) {

    basket.move(1); // Move para a direita

  }

}

// Classe da cesta

class Basket {

  constructor() {

    this.width = 100;

    this.height = 20;

    this.x = width / 2 - this.width / 2;

    this.speed = 5;

  }

  show() {

    fill(139,69,19); // Cor marrom para a cesta

    rect(this.x, height - this.height, this.width, this.height);

  }

  move(dir) {

    if (dir) {

      this.x += dir * this.speed * (keyIsDown(SHIFT) ? 2 : 1); // Acelera com SHIFT

      this.x = constrain(this.x, 0, width - this.width); // Limita movimento dentro da tela

    }

    

    if (keyIsDown(LEFT_ARROW)) {

      this.move(-1);

    } else if (keyIsDown(RIGHT_ARROW)) {

      this.move(1);

    }

   }

}

// Classe da fruta

class Fruit {

  constructor() {

    this.x = random(width);

    this.y = -20; // Começa acima da tela

    this.size = random(20, 40);

    this.speed = random(2, 5);

    

   }

   fall() {

     this.y += this.speed; // Faz a fruta cair

   }

   show() {

     fill(255,0,0); // Cor vermelha para a fruta

     ellipse(this.x, this.y, this.size);

   }

   hits(basket) {

     return (

       this.x > basket.x &&

       this.x < basket.x + basket.width &&

       this.y + this.size / 2 > height - basket.height

     ); // Verifica se a fruta atingiu a cesta

   }

   offScreen() {

     return this.y > height; // Verifica se a fruta saiu da tela

   }

}